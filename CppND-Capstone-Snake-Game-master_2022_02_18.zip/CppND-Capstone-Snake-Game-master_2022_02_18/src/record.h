/*
    The purpose of the record.ccp and record.h files are to save the game score value:
    1. The ReadScoreBoard function reads the Best_Score value from the text file called "scoreboard.txt"
        from the user's last best score value.
    2. If the file does not exist or cannot be opened, a new file will be created and the score is defaulted to zero.
    3. The WriteScoreBoard function writes the Best_Score value to the scoreboard.txt file.
*/

#ifndef RECORD_H
#define RECORD_H
#include <fstream>
#include <string>
using std::string;

class ScoreBoardFile 
{
    public:
    int ReadScoreBoard();     
    void WriteScoreBoard(int &UserNewScore); 
    
    private:
    string filename{"scoreboard.txt"}; // name of the text file
         
};

#endif
