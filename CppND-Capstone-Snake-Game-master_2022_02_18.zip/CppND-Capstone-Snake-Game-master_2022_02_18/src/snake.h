#ifndef SNAKE_H
#define SNAKE_H

#include <vector>
#include "SDL.h"

class Snake {
 public:
  enum class Direction { kUp, kDown, kLeft, kRight }; // snake directional enum

  Snake(int grid_width, int grid_height) // snake object
      : grid_width(grid_width),
        grid_height(grid_height),
        head_x(grid_width / 2),
        head_y(grid_height / 2) {}

  void Update();

  void GrowBody();
  bool SnakeCell(int &x, int &y); 

  Direction direction = Direction::kUp; // set kUp direction to default

  float speed{0.1f};  // set initial default speed
  int size{1};        // set initial default size
  bool alive{true};   // set initial alive to true as default
  float head_x;       
  float head_y;
  std::vector<SDL_Point> body; // vector position of the snake body

 private:
  void UpdateHead();
  void UpdateBody(SDL_Point &current_cell, SDL_Point &prev_cell);

  bool growing{false}; // set snake growth to false by default
  int grid_width;
  int grid_height;
};

#endif