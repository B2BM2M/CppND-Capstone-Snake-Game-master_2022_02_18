/*
    The purpose of the record.ccp and record.h files are to save the game score value:
    1. The ReadScoreBoard function reads the Best_Score value from the text file called "scoreboard.txt"
        which is the user's last best score value saved.Game display window title will display this score value when the game starts.
    2. If the file does not exist or cannot be opened, a new file will be created and the score is defaulted to zero.
    3. The WriteScoreBoard function saves the Best_Score value to the scoreboard.txt file.
*/


#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "record.h"

using std::string;
using namespace std;

// Read score value from the scoreboard.txt file
    int ScoreBoardFile::ReadScoreBoard()
    {
        int score = 0;
        string line, key, value;

        ifstream filestream(filename);
        if(filestream.is_open())
        {           
            while(getline(filestream, line))
            {
                istringstream linestream(line);
                linestream >> key;
                if(key == "Best_Score:")
                {
                    linestream >> value;                    
                    score = stoi(value);
                    return score;
                }
            }
            filestream.close();
        }
        else
        {
            ofstream filestream(filename); //create file the scoreboard.txt if it does not exist
        }
        return score;
    }

// Write user score value to the scoreboard.txt file    
    void ScoreBoardFile::WriteScoreBoard(int &UserNewScore)
    {
        ofstream myfilestream(filename);
        if(myfilestream.is_open())
        {
            myfilestream << "Best_Score: " << UserNewScore << "\n";
            myfilestream.close();
        }
    }



