#include "game.h"
#include <iostream>
#include "SDL.h"
#include <thread>
#include <memory>
Game::Game(std::size_t grid_width, std::size_t grid_height)
    : snake(grid_width, grid_height),
      engine(dev()),
      random_w(0, static_cast<int>(grid_width - 1)),
      random_h(0, static_cast<int>(grid_height - 1)) {
  PlaceFood();
  PlaceLandmine();
  BonusItem();
}

void Game::Run(Controller const &controller, Renderer &renderer,
               std::size_t target_frame_duration) {
  Uint32 title_timestamp = SDL_GetTicks();
  Uint32 frame_start;
  Uint32 frame_end;
  Uint32 frame_duration;
  int frame_count = 0;
  bool running = true;
  
  // get the last saved score before starting a new game
  int highest_score = ReadTextFile.ReadScoreBoard(); 

  while (running) {
    frame_start = SDL_GetTicks();

    // Input, Update, Render - the main game loop.
    controller.HandleInput(running, snake);
    Update();
    renderer.Render(snake, food, landmine, bonusitem); // added landmine and bonusitem

    frame_end = SDL_GetTicks();

    // Keep track of how long each loop through the input/update/render cycle
    // takes.
    frame_count++;
    frame_duration = frame_end - frame_start;

    // After every second, update the window title.
    if (frame_end - title_timestamp >= 1000) {
      renderer.UpdateWindowTitle(highest_score, *score, frame_count); //added player's highest_score
      frame_count = 0;
      title_timestamp = frame_end;
    }

    // If the time for this frame is too small (i.e. frame_duration is
    // smaller than the target ms_per_frame), delay the loop to
    // achieve the correct frame rate.
    if (frame_duration < target_frame_duration) {
      SDL_Delay(target_frame_duration - frame_duration);
    }
  }
}

void Game::PlaceFood() {
  int x, y;
  while (true) {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item before placing
    // food.
    if (!snake.SnakeCell(x, y) && (bonusitem.x != x, bonusitem.y != y) && (landmine.x != x, landmine.y !=y)) {
      food.x = x;
      food.y = y;
      return;
    }
  }
}

void Game::PlaceLandmine() // added landmine obsticle to the game play.
{
  int x, y;
  while(true)
  {
    x = random_w(engine);
    y = random_h(engine);
    // check for food and snake position and not to place landmine on the occupied position.
    if(!snake.SnakeCell(x, y) && (food.x != x, food.y != y) && (bonusitem.x != x, bonusitem.y != y))
    {
      landmine.x = x;
      landmine.y = y;
      return;
    }
  }

}

void Game::BonusItem() // added bonus item.
{
  int x, y;
  while(true)
  {
    x = random_w(engine);
    y = random_h(engine);
    // ensure bonus item will not occupied food and landmine location
    if(!snake.SnakeCell(x, y) && (food.x != x, food.y != y) && (landmine.x != x, landmine.y !=y))
    {
      bonusitem.x = x;
      bonusitem.y = y;
      return;
    }
  }

}

void Game::Update() {
  if (!snake.alive) return;
  snake.Update(); 
  int new_x = static_cast<int>(snake.head_x);
  int new_y = static_cast<int>(snake.head_y);

  // Check if there's food over here
  if (food.x == new_x && food.y == new_y) {
    score = std::unique_ptr<int>(new int(*score +1)); // score unique pointer
    PlaceFood();
    PlaceLandmine();
    BonusItem();
    // Grow snake and increase speed.
    snake.GrowBody();
    snake.speed += 0.02;
     
  }

  // Check if the snake touches the landmine, 
  // snake alive will be false if the snake head touches the landmine
   if(new_x == landmine.x && new_y == landmine.y)
  {
     snake.alive = false;
  } 

   if( bonusitem.x == new_x && bonusitem.y == new_y)
  {
     score = std::unique_ptr<int>(new int(*score +3)); // score unique pointer
     PlaceFood();
     PlaceLandmine();
     snake.GrowBody();
     BonusItem();   
  } 
 

}

int Game::GetScore() const { return *score; }
int Game::GetSize() const { return snake.size; }