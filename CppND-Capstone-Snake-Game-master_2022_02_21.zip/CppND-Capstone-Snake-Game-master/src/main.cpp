#include <iostream>
#include "controller.h"
#include "game.h"
#include "renderer.h"
#include "record.h"

#include <string>



int main() {
  constexpr std::size_t kFramesPerSecond{60};
  constexpr std::size_t kMsPerFrame{1000 / kFramesPerSecond};
  constexpr std::size_t kScreenWidth{640};
  constexpr std::size_t kScreenHeight{640};
  constexpr std::size_t kGridWidth{32};
  constexpr std::size_t kGridHeight{32};

  ScoreBoardFile readwritescore;
  int savedscore = readwritescore.ReadScoreBoard(); // read the saved score value if exist
  
  Renderer renderer(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight);
  Controller controller;
  Game game(kGridWidth, kGridHeight);
  game.Run(controller, renderer, kMsPerFrame);
  std::cout << "Game has terminated successfully!\n";
  int gamescore =  game.GetScore();                 // retrieve the latest game score
  std::cout << "Score: " << gamescore << "\n";
  std::cout << "Size: " << game.GetSize() << "\n";
  
  if(gamescore > savedscore)                       // save score value if new score value is higher then previously recorded
  {
    readwritescore.WriteScoreBoard(gamescore);
    std::cout << "High Score: " << gamescore << "\n";
  }
  else{
    std::cout << "High Score: " << savedscore << "\n";
  }

  return 0;
}