# CPPND: Capstone Snake Game Example

This is a starter repo for the Capstone project in the [Udacity C++ Nanodegree Program](https://www.udacity.com/course/c-plus-plus-nanodegree--nd213). The code for this repo was inspired by [this](https://codereview.stackexchange.com/questions/212296/snake-game-in-c-with-sdl) excellent StackOverflow post and set of responses.

<img src="snake_game.gif"/>

The Capstone Project gives you a chance to integrate what you've learned throughout this program. This project will become an important part of your portfolio to share with current and future colleagues and employers.

In this project, you can build your own C++ application or extend this Snake game, following the principles you have learned throughout this Nanodegree Program. This project will demonstrate that you can independently create applications using a wide range of C++ features.


# Rubric Requirement 

## Dependencies for Running Locally
* cmake >= 3.7
  * All OSes: [click here for installation instructions](https://cmake.org/install/)
* make >= 4.1 (Linux, Mac), 3.81 (Windows)
  * Linux: make is installed by default on most Linux distros
  * Mac: [install Xcode command line tools to get make](https://developer.apple.com/xcode/features/)
  * Windows: [Click here for installation instructions](http://gnuwin32.sourceforge.net/packages/make.htm)
* SDL2 >= 2.0
  * All installation instructions can be found [here](https://wiki.libsdl.org/Installation)
  >Note that for Linux, an `apt` or `apt-get` installation is preferred to building from source. 
* gcc/g++ >= 5.4
  * Linux: gcc / g++ is installed by default on most Linux distros
  * Mac: same deal as make - [install Xcode command line tools](https://developer.apple.com/xcode/features/)
  * Windows: recommend using [MinGW](http://www.mingw.org/)

## Basic Build Instructions

1. Clone this repo.
2. Make a build directory in the top level directory: `mkdir build && cd build`
3. Compile: `cmake .. && make`
4. Run it: `./SnakeGame`.


## Code Engine
* main creates Controller, Game, Renderer, and ScoreBoardFile object. 
* main will try to pull the user's previous "highest_score" from the  scoreboard.txt which will be created if the file does not exist in the /build directory of the project.
* After instantiating the ScoreboardFile, Renderer, Controller, and Game. main initiated the game Run function to start the game loop. 
* When the game ended, the user Score value will be display on the terminal. If new score value is greater than the previous game score, the higher score will be written to a text file called scoreboard.txt file.

* controller.h and controller.cpp handles the user keyboard input. The code will monitor the up/down/left/right and esc key event (through SDL).
* snake.h and snake.cpp uses the Snake class to enable the functionalities such as Direct, Update snake object, GrowBody, SnakeCell position, and whether if the snake is alive.
* record.h and record.cpp has a ScoreBoardFile class that allow the game to read/write a text file called scoreboard.txt or create the file if it does not exist in the /build folder.
* rendere.h and renderer.cpp render the game window size, snake, food, landmine, and update the game-play information on the window top.
* game.h and game.cpp has the scope Run function where the system loop executes the controller HandleInput, Update, Renderer render, and framerate control.

# Loops, Function, I/O
* In the controller.cpp, a pollevent uses the while loop to detects all the directional keys, including the newly added ESCAPE key.
* In the game.cpp, the PlaceLandmine function checks for snakecell and food location then populates the landmine where food and snake are not occupied on the window screen.
* record.h and record.cpp have two function that reads and write the scoreboard.txt file from the /build directory.
* game-play update the user's current score along with the "Highes Score" that the user has achieved from previous game(s).
* update food, snake, landmine, bonusitem on display

# Object Oriented Programming
* record.h and record.cpp has a class called ScoreBoardFile that have two methods; ReadScoreBoard and WriteScoreBoard that are public, and the "filename" which is private.
* The ReadScoreBoard has a "fixed" argurment from the private member while the WriteScoreBoard method that excepts a reference input argument. 

# Memory Management
* In renderer.h and renderer.cpp, using pass by refernce instead of pass by value  when updating the UpdateWindowTitle (line 85) and Render(line 40)
* In the controller.h and controller.cpp, the Snake::Direction uses pass by reference.
* In the record.h and record.cpp, the ScoreBoardFile::WriteScoreBoard scope uses reference as input argument.
* In game.h and game.cpp, unique_ptr was used to update the scores (line 118, 137)

# Concurrency
* In record.h and record.cpp, mutex was implemented during reading of the ScoreBoardFile and also writing to the ScoreBoardFile.

# New features added
* Added esc key input function to end the game
* Created scoreboard.txt file to save the user's highest achievement
* The record.h and record.cpp will open or createthe scoreboard.txt file at the start of the game.
* If the scoreboard.txt exist and has saved score value, the program will load this value to the game window title.
* In the main.cpp, the scoreboard.txt will only be updated to the new score if it's value is greater than the previously saved scored.
* Change snake head and body color, and the color of the food.
* Added additional obsticle such as the landmine. The game will end if the snake head touches the landmine which has the red color coded block.
* Added BonusItem to give user 3 times the score value without increasing the speed.



